class Products{
  final int id;
  final String name;
    final String category;
      final String image;
        final String description;
          int price;
            int quantity;
Products({
  required this.id,
    required this.name,
      required this.category,
        required this.image,
          required this.description,
            required this.price,
              required this.quantity,






});

}

