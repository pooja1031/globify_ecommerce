package com.example.myshopping

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
